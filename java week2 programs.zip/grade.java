import java.util.Scanner;
class grade{
public static void main(String[] args){
Scanner x=new Scanner(System.in);
System.out.print("enter the CIE marks:");
int cie=x.nextInt();
System.out.print("enter the SEE marks:");
int see=x.nextInt();
int f=cie+see/2;
if (f>=90)
System.out.println("the student grade is:S");
else if (f>=80 && f<90)
System.out.println("the student grade is:A");
else if (f>=70 && f<80)
System.out.println("the student grade is:B");
else if(f>=60 && f<70)
System.out.println("the student grade is:c");
else if(f>=50 && f<60)
System.out.println("the student grade is:d");
else
System.out.println("the student grade is:e");
}
}