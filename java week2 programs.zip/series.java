import java.util.Scanner;
class series{
public static void main(String[] args){
Scanner x=new Scanner(System.in);
System.out.print("enter the number of rows:");
int n=x.nextInt();
int k=1;
for(int i=0;i<n;i++){
for(int j=0;j<=i;j++)
System.out.print(k++ +"\t");
System.out.println("");
}
}
}